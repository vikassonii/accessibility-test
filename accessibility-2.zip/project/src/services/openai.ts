import axios from 'axios';
import type { AccessibilityIssue, AIExplanation } from '../types';

const OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';

export async function getAccessibilityExplanation(issue: AccessibilityIssue): Promise<AIExplanation> {
  try {
    const response = await axios.post(
      OPENAI_API_URL,
      {
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an accessibility expert helping developers fix WCAG issues. Provide detailed explanations and code examples.'
          },
          {
            role: 'user',
            content: `Please analyze this accessibility issue and provide:
              1. A detailed explanation of why it's important
              2. How to fix it with code examples
              3. Suggestions for ARIA roles and semantic HTML
              4. Keyboard navigation considerations
              
              Issue: ${issue.message}
              Context: ${issue.context}
              Code: ${issue.code}
              Selector: ${issue.selector}`
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      },
      {
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const aiResponse = response.data.choices[0].message.content;
    const [explanation, suggestedFix, codeExample] = parseAIResponse(aiResponse);

    return {
      issue: issue.message,
      explanation,
      suggestedFix,
      codeExample
    };
  } catch (error) {
    console.error('Error getting AI explanation:', error);
    throw new Error('Failed to get AI explanation');
  }
}

function parseAIResponse(response: string): [string, string, string] {
  // Split the response into sections based on common patterns
  const sections = response.split(/\n\n|\r\n\r\n/);
  
  let explanation = '';
  let suggestedFix = '';
  let codeExample = '';

  sections.forEach(section => {
    if (section.toLowerCase().includes('code example') || section.includes('```')) {
      codeExample = section.replace(/```[a-z]*\n?/g, '').trim();
    } else if (section.toLowerCase().includes('how to fix') || section.toLowerCase().includes('solution')) {
      suggestedFix = section.trim();
    } else {
      explanation += section + '\n';
    }
  });

  return [explanation.trim(), suggestedFix, codeExample];
}