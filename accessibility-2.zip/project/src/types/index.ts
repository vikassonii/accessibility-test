export interface AccessibilityIssue {
  code: string;
  type: 'error' | 'warning' | 'notice';
  message: string;
  context: string;
  selector: string;
  runner: string;
  runnerExtras?: any;
}

export interface AccessibilityReport {
  documentTitle: string;
  pageUrl: string;
  issues: AccessibilityIssue[];
  timestamp: string;
}

export interface AIExplanation {
  issue: string;
  explanation: string;
  suggestedFix: string;
  codeExample: string;
}