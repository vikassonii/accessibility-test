import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { URLScanner } from './components/URLScanner';
import { AccessibilityReport } from './components/AccessibilityReport';
import { Brain } from 'lucide-react';
import axios from 'axios';

function App() {
  const [isScanning, setIsScanning] = React.useState(false);
  const [issues, setIssues] = React.useState([]);
  const [error, setError] = React.useState('');

  const handleScan = async (url: string) => {
    setIsScanning(true);
    setError('');
    
    try {
      const apiUrl = `${window.location.protocol}//${window.location.hostname}:3001/scan`;
      const response = await axios.post(apiUrl, { url });
      
      if (response.data.error) {
        throw new Error(response.data.error);
      }

      const formattedIssues = (response.data.issues || []).map(issue => ({
        type: issue.type || 'error',
        message: issue.message || '',
        context: issue.context || '',
        selector: issue.selector || '',
        code: issue.code || '',
        runner: 'pa11y'
      }));
      
      setIssues(formattedIssues);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.response?.data?.details || err.message || 'Failed to scan URL';
      setError(errorMessage);
      console.error('Scanning error:', err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleAIHelp = (issue: any) => {
    console.log('Requesting AI help for:', issue);
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route
              path="/"
              element={
                <div className="text-center">
                  <h1 className="text-4xl font-bold text-gray-900 mb-8">
                    AI-Powered Web Accessibility Testing
                  </h1>
                  <div className="flex justify-center mb-12">
                    <Brain className="h-24 w-24 text-indigo-600" />
                  </div>
                  <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-12">
                    Scan your website for accessibility issues and get AI-powered suggestions
                    for improvements. Make your web content accessible to everyone.
                  </p>
                  <URLScanner onScan={handleScan} isLoading={isScanning} />
                  {error && (
                    <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
                      {error}
                    </div>
                  )}
                  {issues.length > 0 && (
                    <AccessibilityReport
                      issues={issues}
                      onRequestAIHelp={handleAIHelp}
                    />
                  )}
                </div>
              }
            />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;