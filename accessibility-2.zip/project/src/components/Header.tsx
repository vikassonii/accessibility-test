import React from 'react';
import { Link } from 'react-router-dom';
import { Accessibility, Brain, Home } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-indigo-600 text-white shadow-lg">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Accessibility className="h-8 w-8" />
              <span className="text-xl font-bold">AI Accessibility Tester</span>
            </Link>
          </div>
          <div className="flex space-x-4">
            <Link
              to="/"
              className="flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium hover:bg-indigo-500"
            >
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link
              to="/scan"
              className="flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium hover:bg-indigo-500"
            >
              <Brain className="h-4 w-4" />
              <span>AI Scan</span>
            </Link>
          </div>
        </div>
      </nav>
    </header>
  );
};