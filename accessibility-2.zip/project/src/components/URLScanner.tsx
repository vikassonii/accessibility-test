import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface URLScannerProps {
  onScan: (url: string) => void;
  isLoading: boolean;
}

export const URLScanner: React.FC<URLScannerProps> = ({ onScan, isLoading }) => {
  const [url, setUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url) onScan(url);
  };

  return (
    <div className="w-full max-w-3xl mx-auto p-6">
      <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
        <div className="relative">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter website URL to scan"
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            required
          />
          <button
            type="submit"
            disabled={isLoading}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
          >
            <Search className="h-4 w-4" />
            <span>{isLoading ? 'Scanning...' : 'Scan'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};