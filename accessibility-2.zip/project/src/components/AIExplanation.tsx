import React from 'react';
import { Code2, Lightbulb, Info } from 'lucide-react';
import type { AIExplanation } from '../types';

interface AIExplanationProps {
  explanation: AIExplanation;
  onClose: () => void;
}

export const AIExplanationModal: React.FC<AIExplanationProps> = ({
  explanation,
  onClose
}) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h3 className="text-2xl font-bold text-gray-900">AI Accessibility Analysis</h3>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <span className="sr-only">Close</span>
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="space-y-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center mb-2">
                <Info className="h-5 w-5 text-blue-600 mr-2" />
                <h4 className="font-semibold text-blue-900">Issue</h4>
              </div>
              <p className="text-blue-800">{explanation.issue}</p>
            </div>

            <div>
              <div className="flex items-center mb-2">
                <Lightbulb className="h-5 w-5 text-indigo-600 mr-2" />
                <h4 className="font-semibold text-gray-900">Explanation</h4>
              </div>
              <p className="text-gray-700 whitespace-pre-wrap">{explanation.explanation}</p>
            </div>

            <div>
              <div className="flex items-center mb-2">
                <Code2 className="h-5 w-5 text-green-600 mr-2" />
                <h4 className="font-semibold text-gray-900">Suggested Fix</h4>
              </div>
              <p className="text-gray-700 mb-4">{explanation.suggestedFix}</p>
              <pre className="bg-gray-800 text-white p-4 rounded-lg overflow-x-auto">
                <code>{explanation.codeExample}</code>
              </pre>
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};