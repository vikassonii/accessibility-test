import React, { useState } from 'react';
import { AlertTriangle, AlertCircle, Info, Download, Brain } from 'lucide-react';
import type { AccessibilityIssue, AIExplanation } from '../types';
import { AIExplanationModal } from './AIExplanation';
import { getAccessibilityExplanation } from '../services/openai';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

interface AccessibilityReportProps {
  issues: AccessibilityIssue[];
  onRequestAIHelp: (issue: AccessibilityIssue) => void;
}

export const AccessibilityReport: React.FC<AccessibilityReportProps> = ({
  issues,
  onRequestAIHelp,
}) => {
  const reportRef = React.useRef<HTMLDivElement>(null);
  const [aiExplanation, setAiExplanation] = useState<AIExplanation | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleRequestAIHelp = async (issue: AccessibilityIssue) => {
    setIsLoading(true);
    try {
      const explanation = await getAccessibilityExplanation(issue);
      setAiExplanation(explanation);
    } catch (error) {
      console.error('Error getting AI explanation:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!reportRef.current) return;

    try {
      const canvas = await html2canvas(reportRef.current);
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: [canvas.width, canvas.height]
      });

      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save('accessibility-report.pdf');
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const getIssueIcon = (type: string) => {
    switch (type) {
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getIssueClass = (type: string) => {
    switch (type) {
      case 'error':
        return 'border-red-100 bg-red-50';
      case 'warning':
        return 'border-yellow-100 bg-yellow-50';
      default:
        return 'border-blue-100 bg-blue-50';
    }
  };

  const issuesByType = {
    error: issues.filter(issue => issue.type === 'error'),
    warning: issues.filter(issue => issue.type === 'warning'),
    notice: issues.filter(issue => issue.type === 'notice')
  };

  return (
    <>
      <div className="w-full max-w-4xl mx-auto p-6" ref={reportRef}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Accessibility Report</h2>
          <button
            className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            onClick={handleDownloadPDF}
          >
            <Download className="h-4 w-4" />
            <span>Download PDF</span>
          </button>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-red-100 p-4 rounded-lg">
            <h3 className="font-semibold text-red-800">Errors</h3>
            <p className="text-2xl font-bold text-red-600">{issuesByType.error.length}</p>
          </div>
          <div className="bg-yellow-100 p-4 rounded-lg">
            <h3 className="font-semibold text-yellow-800">Warnings</h3>
            <p className="text-2xl font-bold text-yellow-600">{issuesByType.warning.length}</p>
          </div>
          <div className="bg-blue-100 p-4 rounded-lg">
            <h3 className="font-semibold text-blue-800">Notices</h3>
            <p className="text-2xl font-bold text-blue-600">{issuesByType.notice.length}</p>
          </div>
        </div>

        <div className="space-y-6">
          {Object.entries(issuesByType).map(([type, typeIssues]) => (
            typeIssues.length > 0 && (
              <div key={type} className="space-y-4">
                <h3 className="text-xl font-semibold capitalize">{type}s</h3>
                {typeIssues.map((issue, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border ${getIssueClass(issue.type)} transition-all hover:shadow-md`}
                  >
                    <div className="flex items-start space-x-3">
                      {getIssueIcon(issue.type)}
                      <div className="flex-1">
                        <h4 className="font-semibold text-lg">{issue.message}</h4>
                        <div className="mt-2 p-2 bg-white bg-opacity-50 rounded">
                          <code className="text-sm font-mono">{issue.context}</code>
                        </div>
                        <div className="mt-2">
                          <span className="inline-block px-2 py-1 text-sm bg-white bg-opacity-50 rounded">
                            {issue.selector}
                          </span>
                        </div>
                        <div className="mt-3 flex space-x-4">
                          <button
                            onClick={() => handleRequestAIHelp(issue)}
                            disabled={isLoading}
                            className="text-indigo-600 hover:text-indigo-700 text-sm font-medium flex items-center space-x-1 disabled:opacity-50"
                          >
                            <Brain className="h-4 w-4" />
                            <span>{isLoading ? 'Loading...' : 'Get AI Help'}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )
          ))}
        </div>
      </div>

      {aiExplanation && (
        <AIExplanationModal
          explanation={aiExplanation}
          onClose={() => setAiExplanation(null)}
        />
      )}
    </>
  );
};