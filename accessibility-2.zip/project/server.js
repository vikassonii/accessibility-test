import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3001;

// Configure CORS
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json());
app.use(express.static('dist'));

// Create axios instance with improved configuration
const axiosInstance = axios.create({
  timeout: 10000, // Reduced timeout to prevent hanging
  maxRedirects: 3,
  validateStatus: (status) => status < 500,
  headers: {
    'Accept': 'text/html',
    'User-Agent': 'Mozilla/5.0 (compatible; AccessibilityChecker/1.0)'
  }
});

// Simplified HTML patterns to reduce processing load
const HTML_PATTERNS = {
  IMG: /<img[^>]+>/g,
  ALT: /alt=["']([^"']*)["']/,
  HEADING: /<h([1-6])[^>]*>.*?<\/h\1>/g,
  INPUT: /<input[^>]+>/g,
  LABEL: /<label[^>]*>.*?<\/label>/g
};

// Simplified accessibility checks
const checkAccessibility = {
  images: (dom) => {
    const issues = [];
    const images = dom.match(HTML_PATTERNS.IMG) || [];
    
    images.forEach(img => {
      const altMatch = img.match(HTML_PATTERNS.ALT);
      if (!altMatch) {
        issues.push({
          type: 'error',
          message: 'Image missing alt attribute',
          context: img.slice(0, 100),
          code: 'WCAG2.1.A.1.1.1',
          selector: 'img'
        });
      }
    });
    return issues;
  },

  headings: (dom) => {
    const issues = [];
    const headings = Array.from(dom.matchAll(HTML_PATTERNS.HEADING));
    let previousLevel = 0;

    headings.forEach(match => {
      const level = parseInt(match[1]);
      if (level - previousLevel > 1) {
        issues.push({
          type: 'error',
          message: `Heading level skipped from H${previousLevel} to H${level}`,
          context: match[0].slice(0, 100),
          code: 'WCAG2.1.AA.1.3.1',
          selector: `h${level}`
        });
      }
      previousLevel = level;
    });
    return issues;
  }
};

// API endpoint for scanning
app.post('/scan', async (req, res) => {
  try {
    const { url } = req.body;
    
    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    try {
      new URL(url);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid URL format' });
    }

    try {
      // Use CORS proxy directly instead of trying direct URL first
      const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
      const response = await axiosInstance.get(proxyUrl);
      const html = response.data;

      if (typeof html !== 'string') {
        throw new Error('Invalid HTML response');
      }

      // Run simplified accessibility checks
      const issues = [
        ...checkAccessibility.images(html),
        ...checkAccessibility.headings(html)
      ];

      // Create a plain object response
      const result = {
        documentTitle: 'Accessibility Report',
        pageUrl: url,
        issues: issues.map(issue => ({
          type: String(issue.type || 'error'),
          message: String(issue.message || ''),
          context: String(issue.context || '').slice(0, 100),
          selector: String(issue.selector || ''),
          code: String(issue.code || '')
        })),
        timestamp: new Date().toISOString()
      };

      res.json(result);
    } catch (error) {
      console.error('Error fetching URL:', error);
      res.status(500).json({
        error: 'Failed to fetch URL',
        details: error.message
      });
    }
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});