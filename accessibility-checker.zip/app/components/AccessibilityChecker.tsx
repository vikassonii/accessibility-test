"use client"

import { useState, type React } from "react"
import { checkAccessibility } from "../actions/checkAccessibility"
import { AlertCircle, CheckCircle } from "lucide-react"

export default function AccessibilityChecker() {
  const [url, setUrl] = useState("")
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const accessibilityResults = await checkAccessibility(url)
      setResults(accessibilityResults)
    } catch (error) {
      console.error("Error checking accessibility:", error)
      setResults({ error: "An error occurred while checking accessibility." })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden">
      <form onSubmit={handleSubmit} className="p-6">
        <div className="flex items-center border-b border-gray-300 py-2">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter website URL"
            required
            className="appearance-none bg-transparent border-none w-full text-gray-700 mr-3 py-1 px-2 leading-tight focus:outline-none"
          />
          <button
            type="submit"
            disabled={loading}
            className="flex-shrink-0 bg-blue-500 hover:bg-blue-700 border-blue-500 hover:border-blue-700 text-sm border-4 text-white py-1 px-2 rounded disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Checking..." : "Check Accessibility"}
          </button>
        </div>
      </form>
      {results && <AccessibilityResults results={results} />}
    </div>
  )
}

function AccessibilityResults({ results }: { results: any }) {
  if (results.error) {
    return (
      <div className="p-6 bg-red-100 border-t-4 border-red-500 rounded-b text-red-900">
        <div className="flex">
          <div className="py-1">
            <AlertCircle className="h-6 w-6 text-red-500 mr-4" />
          </div>
          <div>
            <p className="font-bold">Error</p>
            <p className="text-sm">{results.error}</p>
          </div>
        </div>
      </div>
    )
  }

  const issueCount = results.issues.length
  const issueTypes = {
    error: results.issues.filter((issue: any) => issue.type === "error").length,
    warning: results.issues.filter((issue: any) => issue.type === "warning").length,
  }

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Accessibility Report</h2>
      <div className="mb-6 p-4 bg-gray-100 rounded-lg">
        <p className="text-lg font-medium">
          Total Issues Found: <span className="font-bold text-blue-600">{issueCount}</span>
        </p>
        <p className="text-sm text-gray-600">
          Errors: <span className="font-medium text-red-600">{issueTypes.error}</span>, Warnings:{" "}
          <span className="font-medium text-yellow-600">{issueTypes.warning}</span>
        </p>
      </div>
      {issueCount === 0 ? (
        <div className="flex items-center p-4 bg-green-100 rounded-lg">
          <CheckCircle className="h-6 w-6 text-green-500 mr-2" />
          <p className="text-green-700 font-medium">No accessibility issues found!</p>
        </div>
      ) : (
        <ul className="space-y-4">
          {results.issues.map((issue: any, index: number) => (
            <li key={index} className={`p-4 rounded-lg ${issue.type === "error" ? "bg-red-50" : "bg-yellow-50"}`}>
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold text-lg">{issue.code}</p>
                  <p className={`text-sm ${issue.type === "error" ? "text-red-600" : "text-yellow-600"}`}>
                    {issue.type}
                  </p>
                </div>
                <span
                  className={`px-2 py-1 rounded text-xs font-bold uppercase ${issue.type === "error" ? "bg-red-200 text-red-800" : "bg-yellow-200 text-yellow-800"}`}
                >
                  {issue.type}
                </span>
              </div>
              <p className="mt-2">{issue.message}</p>
              <details className="mt-2">
                <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">View Context</summary>
                <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-x-auto">{issue.context}</pre>
              </details>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

