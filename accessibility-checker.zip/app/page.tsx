import AccessibilityChecker from "./components/AccessibilityChecker"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-100 to-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold text-center text-blue-800 mb-8">Website Accessibility Checker</h1>
        <AccessibilityChecker />
      </div>
    </main>
  )
}

