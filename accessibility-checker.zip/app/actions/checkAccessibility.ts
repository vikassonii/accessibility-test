"use server"

import { parse } from "node-html-parser"

async function fetchHtml(url: string): Promise<string> {
  const response = await fetch(url)
  return await response.text()
}

function checkImagesForAltText(root: any): any[] {
  const images = root.querySelectorAll("img")
  return images
    .filter((img: any) => !img.getAttribute("alt"))
    .map((img: any) => ({
      code: "missing-alt",
      message: "Image is missing alt text. Alt text is important for screen readers and SEO.",
      context: img.toString(),
      type: "error",
    }))
}

function checkHeadingOrder(root: any): any[] {
  const headings = root.querySelectorAll("h1, h2, h3, h4, h5, h6")
  const issues: any[] = []
  let lastLevel = 0

  headings.forEach((heading: any) => {
    const currentLevel = Number.parseInt(heading.tagName[1])
    if (currentLevel - lastLevel > 1) {
      issues.push({
        code: "heading-order",
        message: `Heading level jumped from h${lastLevel} to h${currentLevel}. This can be confusing for screen reader users.`,
        context: heading.toString(),
        type: "warning",
      })
    }
    lastLevel = currentLevel
  })

  return issues
}

function checkForLabeledInputs(root: any): any[] {
  const inputs = root.querySelectorAll('input:not([type="hidden"])')
  return inputs
    .filter(
      (input: any) => !input.getAttribute("id") || !root.querySelector(`label[for="${input.getAttribute("id")}"]`),
    )
    .map((input: any) => ({
      code: "unlabeled-input",
      message:
        "Input field is not associated with a label. This can make the form difficult to use for screen reader users.",
      context: input.toString(),
      type: "error",
    }))
}

export async function checkAccessibility(url: string) {
  try {
    const html = await fetchHtml(url)
    const root = parse(html)

    const issues = [...checkImagesForAltText(root), ...checkHeadingOrder(root), ...checkForLabeledInputs(root)]

    return { issues }
  } catch (error) {
    console.error("Error running accessibility check:", error)
    throw new Error("Failed to check accessibility")
  }
}

